# DS Recipes Templates

These Python templates cover data preprocessing, metrics, time-series forecasting (naïve, Holt–Winters, SARIMA),
ACF/PACF diagnostics, classification (logistic), PCA, neural nets (MLP, LSTM template), directionality/causality
(Granger), transfer entropy (simple estimator), survival analysis (lifelines template), and DBN/HMM templates.

> Charts use matplotlib (no seaborn). Some blocks are templates requiring optional libs (tensorflow, lifelines, pomegranate).
